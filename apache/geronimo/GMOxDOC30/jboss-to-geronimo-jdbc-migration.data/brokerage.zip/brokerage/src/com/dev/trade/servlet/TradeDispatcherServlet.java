package com.dev.trade.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dev.trade.bo.User;
import com.dev.trade.dao.TradeDAO;
import com.dev.trade.exception.DBException;

public class TradeDispatcherServlet extends HttpServlet {

	private TradeDAO tradeDAO = null;

	private HttpSession session = null;

	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		try {
			tradeDAO = new TradeDAO();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			session = request.getSession(true);
			session.removeAttribute("status");
			String page = request.getServletPath();
			if ("/login".equals(page)) {
				String userId = (String) request.getParameter("user");
				String password = (String) request.getParameter("password");
				if (userId != null && password != null) {
					User user = tradeDAO.getUserByUserId(userId);
					session.setAttribute("user", user);
					if (user != null && password.equals(user.getPassword())) {
						page = "/stocks";
						session.setAttribute("userId", userId);
						session.setAttribute("password", password);
						List stocks = tradeDAO.getStocks();
						session.setAttribute("stocks", stocks);
					} else {
						page = "/login";
						session.setAttribute("status",
								"Logon Failed Please Try Again!");
					}
				} else {
					page = "/login";
				}

			} else if ("/stocks".equals(page)) {
				List stocks = tradeDAO.getStocks();
				session.setAttribute("stocks", stocks);
			} else if ("/userstocks".equals(page)) {
				String userId = (String) session.getAttribute("userId");
				List userStocks = tradeDAO.getUserStocks(userId);
				session.setAttribute("userStocks", userStocks);
			} else if ("/register".equals(page)) {
				String userId = request.getParameter("user");
				String name = request.getParameter("name");
				String password = request.getParameter("password");
				String address = request.getParameter("address");
				float cash = Float
						.parseFloat((request.getParameter("cash") == null) ? "0"
								: request.getParameter("cash"));
				if (userId != null && name != null && password != null
						&& address != null && cash != 0) {
					User user = tradeDAO.getUserByUserId(userId);
					if (user == null) {
						boolean status = tradeDAO.addUser(userId, name,
								password, address, cash);
						if (status) {
							page = "/login";
						} else {
							page = "/register";
							session.setAttribute("status",
									"Registration Failed Please Try Again!");
						}
					} else {
						page = "/register";
						session.setAttribute("status",
								"Registration Failed User Already Exists!");
					}

				}else if (userId != null && name != null && password != null
						&& address != null && cash == 0) {
						session.setAttribute("status",
								"Registration Failed Not enough Cash!");
						page = "/register";

				}else {
					page = "/register";
				}

			} else if ("/sell".equals(page)) {
				page = "/userstocks";
				String userId = (String) session.getAttribute("userId");
				String stockId = request.getParameter("select");
				int quantity = Integer.parseInt(request
						.getParameter("sellQuantity"));
				boolean status = tradeDAO.sellStock(userId, stockId, quantity);
				if (!status) {
					session
							.setAttribute("status",
									"Not Enough Stocks or Operation Failed Please Try Again!");
				}
				List userStocks = tradeDAO.getUserStocks(userId);
				session.setAttribute("userStocks", userStocks);
				User user = tradeDAO.getUserByUserId(userId);
				session.setAttribute("user", user);
			} else if ("/buy".equals(page)) {
				page = "/stocks";
				String userId = (String) session.getAttribute("userId");
				String stockId = request.getParameter("select");
				int quantity = Integer.parseInt(request
						.getParameter("buyQuantity"));
				boolean status = tradeDAO.buyStock(userId, stockId, quantity);
				if (!status) {
					session
							.setAttribute("status",
									"Not Enough Money or Operation Failed Please Try Again!");
				}
				List userStocks = tradeDAO.getUserStocks(userId);
				session.setAttribute("userStocks", userStocks);
				User user = tradeDAO.getUserByUserId(userId);
				session.setAttribute("user", user);
			}

			request.getRequestDispatcher(page + ".jsp").forward(request,
					response);
		} catch (DBException e) {
			throw new ServletException(e.getMessage());
		} catch (Exception ex) {
			throw new ServletException(ex.getMessage());
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		doGet(request, response);
	}

	public void destroy() {
			// TODO Auto-generated method stub
		super.destroy();
		try {
			tradeDAO.remove();
			} catch (DBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
