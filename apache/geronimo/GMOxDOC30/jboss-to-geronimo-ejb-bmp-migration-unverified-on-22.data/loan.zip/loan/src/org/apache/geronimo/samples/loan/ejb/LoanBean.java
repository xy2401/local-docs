package org.apache.geronimo.samples.loan.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.ObjectNotFoundException;
import javax.ejb.RemoveException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @ejb.bean type="BMP" bmp-version="2.x" name="Loan" local-jndi-name="Loan" view-type="local"
 * 		primkey-field="loanId"
 * @ejb.interface generate="local" local-class="org.apache.geronimo.samples.loan.ejb.LoanLocal"
 * @ejb.home generate="local" local-class="org.apache.geronimo.samples.loan.ejb.LoanHomeLocal"
 * @ejb.transaction type="Required"
 * @ejb.resource-ref res-ref-name="jdbc/LoanDataSource" res-type="javax.sql.DataSource" res-auth="Container"
 * 
 * @ejb.persistence table-name="LOAN"
 *          
 */
public class LoanBean implements EntityBean {

    /** The entity context */
    private EntityContext context;
    
    private Connection connection = null;
    
    private Integer loanId;
    private String customerName;
    private Double loanAmount;
    private String address;
    private Double annualSalary;
    private Integer loanStatus;
    
    /**
     * @ejb.interface-method view-type = "local"
     * @return
     */
    public String getAddress() {
		return address;
	}
    
    /**
     * @ejb.interface-method view-type = "local"
     * @param address
     */
	public void setAddress(String address) {
		this.address = address;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @return
	 */
	public Double getAnnualSalary() {
		return annualSalary;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @param annualSalary
	 */
	public void setAnnualSalary(Double annualSalary) {
		this.annualSalary = annualSalary;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @return
	 */
	public String getCustomerName() {
		return customerName;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @param customerName
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @return
	 */
	public Double getLoanAmount() {
		return loanAmount;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @param loanAmount
	 */
	public void setLoanAmount(Double loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @return
	 */
	public Integer getLoanId() {
		return loanId;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @param loanId
	 */
	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @return
	 */
	public Integer getLoanStatus() {
		return loanStatus;
	}
	
	/**
	 * @ejb.interface-method view-type = "local"
	 * @param loanStatus
	 */
	public void setLoanStatus(Integer loanStatus) {
		this.loanStatus = loanStatus;
	}

	/**
	 * @ejb.create-method
	 * @param customerName
	 * @param loanAmount
	 * @param address
	 * @param annualSalary
	 * @return
	 * @throws CreateException
	 */
    public Integer ejbCreate(String customerName, Double loanAmount, String address, Double annualSalary) throws CreateException {
        try {
        	openConnection();
        	this.loanId = getNextLoanId();
            this.customerName = customerName;
            this.loanAmount = loanAmount;
            this.address = address;
            this.annualSalary = annualSalary;
            this.loanStatus = new Integer(0); //Not Approved Yet
            insertRow();
            closeConnection();
        } catch (Exception e) {
           throw new EJBException("ejbCreate: "+e.getMessage());
        }
        return this.loanId;
    }

    /**
     * 
     * @param id
     * @param name
     * @param loanAmount
     * @throws CreateException
     */
    public void ejbPostCreate(String customerName, Double loanAmount, String address, Double annualSalary) throws CreateException {
    }
    
    public Integer ejbFindByPrimaryKey(Integer primKey) throws FinderException {
        boolean status = false;
        
        try{
            openConnection();
            status = selectByPrimaryKey(primKey);
            closeConnection();
        }catch(Exception e){
            throw new EJBException("ejbFindByPrimaryKey: "+e.getMessage());
        }
        
        if(status){
            return primKey;
        }else {
            throw new ObjectNotFoundException();
        }
    }
    
    public Collection ejbFindByAll() throws FinderException {
        Collection result = null;
        
        try{
          openConnection();  
          result = selectAll();
          closeConnection();
        }catch (Exception e){
            throw new EJBException("ejbFindByAll: "+e.getMessage());
        }
        
        if(result.isEmpty()){
            throw new ObjectNotFoundException("No rows found");
        }else {
            return result;
        }
    }
    
    public void ejbActivate() throws EJBException, RemoteException {
        this.loanId = (Integer)context.getPrimaryKey();
    }
    
    /* (non-Javadoc)
     * @see javax.ejb.EntityBean#ejbLoad()
     */
    public void ejbLoad() throws EJBException, RemoteException {
        try {
            openConnection();
            loadRow();
            closeConnection();
        } catch (Exception e) {
            throw new EJBException("ejbLoad: "+e.getMessage());
        }
    }
    
    /* (non-Javadoc)
     * @see javax.ejb.EntityBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }
    
    /* (non-Javadoc)
     * @see javax.ejb.EntityBean#ejbRemove()
     */
    public void ejbRemove()
        throws RemoveException,
        EJBException,
        RemoteException {
        
        try {
            openConnection();
            deleteRow();
            closeConnection();
        } catch (Exception e) {
            throw new EJBException("ejbRemove:"+e.getMessage());
        } 
    }
    
    /* (non-Javadoc)
     * @see javax.ejb.EntityBean#ejbStore()
     */
    public void ejbStore() throws EJBException, RemoteException {
        try {
            openConnection();
            storeRow();
            closeConnection();
        } catch (Exception e) {
            throw new EJBException("ejbStore: "+e.getMessage());
        }
    }
    
    /**
     * 
     */
     public void setEntityContext(EntityContext newContext) throws EJBException {
         context = newContext;
     }

     /**
      * 
      */
     public void unsetEntityContext() throws EJBException {
         context = null;
     }
     
     private void openConnection() throws NamingException, SQLException {
         Context context = new InitialContext();
         DataSource ds = (DataSource)context.lookup("java:comp/env/jdbc/LoanDataSource");
         connection = ds.getConnection();
     }
     
     private void closeConnection() throws SQLException {
         connection.close();
     }
     
     private void insertRow() throws SQLException {
         String SQL = "INSERT INTO LOAN (LOAN_ID, CUSTOMER_NAME, LOAN, ADDRESS, ANNUAL_SALARY, LOAN_STATUS) VALUES (?,?,?,?,?,?)";
         PreparedStatement pStmt = connection.prepareStatement(SQL);
         pStmt.setInt(1, loanId.intValue());
         pStmt.setString(2, customerName);
         pStmt.setDouble(3, loanAmount.doubleValue());
         pStmt.setString(4, address);
         pStmt.setDouble(5, annualSalary.doubleValue());
         pStmt.setInt(6, loanStatus.intValue());
         
         pStmt.executeUpdate();
         pStmt.close();
     }
     
     private void deleteRow() throws SQLException {
         String SQL = "DELETE FROM LOAN WHERE LOAN_ID = ?";
         PreparedStatement pStmt = connection.prepareStatement(SQL);
         pStmt.setInt(1, loanId.intValue());
         
         pStmt.executeUpdate();
         pStmt.close();
     }
    
    private boolean selectByPrimaryKey(Integer key) throws SQLException {
        String SQL = "SELECT LOAN_ID, CUSTOMER_NAME, LOAN, ADDRESS, ANNUAL_SALARY, LOAN_STATUS FROM CUSTOMER WHERE LOAN_ID = ?";
        PreparedStatement pStmt = connection.prepareStatement(SQL);
        pStmt.setInt(1, key.intValue());
        ResultSet rs = pStmt.executeQuery();
        boolean status = rs.next();
        
        rs.close();
        pStmt.close();
        return status;
    }
    
    private Collection selectAll() throws SQLException {
        String SQL = "SELECT LOAN_ID, CUSTOMER_NAME, LOAN, ADDRESS, ANNUAL_SALARY, LOAN_STATUS FROM LOAN";
        ArrayList dataSet = new ArrayList();
        PreparedStatement pStmt = connection.prepareStatement(SQL);
        ResultSet rs = pStmt.executeQuery();
        
        while(rs.next()){
        	dataSet.add(new Integer(rs.getInt("LOAN_ID")));
        }
        
        rs.close();
        pStmt.close();
        return dataSet;
    }
    
    private void loadRow() throws SQLException {
        String SQL = "SELECT LOAN_ID, CUSTOMER_NAME, LOAN, ADDRESS, ANNUAL_SALARY, LOAN_STATUS FROM LOAN WHERE LOAN_ID = ?";
        PreparedStatement pStmt = connection.prepareStatement(SQL);
        pStmt.setInt(1, loanId.intValue());
        
        ResultSet rs = pStmt.executeQuery();
        
        if(rs.next()){
            this.loanId = new Integer(rs.getInt("LOAN_ID"));
            this.customerName = rs.getString("CUSTOMER_NAME");
            this.loanAmount = new Double(rs.getDouble("LOAN"));
            this.address = rs.getString("ADDRESS");
            this.annualSalary = new Double(rs.getDouble("ANNUAL_SALARY"));
            this.loanStatus = new Integer(rs.getInt("LOAN_STATUS"));
        }
        
        rs.close();
        pStmt.close();
    }
    
    private void storeRow() throws SQLException {
        String SQL = "UPDATE LOAN SET CUSTOMER_NAME=?, ADDRESS=?, ANNUAL_SALARY=?, LOAN=?, LOAN_STATUS=? WHERE LOAN_ID=?";

        PreparedStatement pStmt = connection.prepareStatement(SQL);
        
        pStmt.setString(1, customerName);
        pStmt.setString(2, address);
        pStmt.setDouble(3, annualSalary.doubleValue());
        pStmt.setDouble(4, loanAmount.doubleValue());
        pStmt.setInt(5, loanId.intValue());
        pStmt.setInt(6, loanStatus.intValue());
        
        pStmt.executeUpdate();
        pStmt.close();
        
//        if(status == 0){
//            throw new NoSuchEntityException("Storing row for id "+customerId+" failed");
//        }        
        
    }
    
    private Integer getNextLoanId() throws SQLException {
    	 Integer tempPrimaryKey = new Integer(0);
    	 
    	 String SQL = "SELECT MAX(LOAN_ID) FROM LOAN";

         PreparedStatement pStmt = connection.prepareStatement(SQL);
         ResultSet rs = pStmt.executeQuery();
         
         if(rs.next()){
        	tempPrimaryKey = new Integer(rs.getInt(1)+1); 
         }
         return tempPrimaryKey;
    }

 
}