package org.apache.geronimo.samples.loan.client;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import org.apache.geronimo.samples.loan.ejb.LoanManager;
import org.apache.geronimo.samples.loan.ejb.LoanManagerHome;
import org.apache.geronimo.samples.loan.util.PropertyLoader;

public class LoanStatusChanger {

   private static final String CLIENT_PROP_NAME = "client.properties";
   
   private static final String FACTORY_INITIAL = "java.naming.factory.initial";
   private static final String FACTORY_URL = "java.naming.factory.url.pkgs";
   private static final String PROVIDER_URL = "java.naming.provider.url";
   
   private static final String ENVIROMENT = "loan.enviroment";
   
   private static final String SECURITY_PRINCIPAL = "java.naming.security.principal";
   private static final String SECURITY_CREDENTIALS = "java.naming.security.credentials";
   
   private static final String JBOSS_ENVIROMENT = "jboss";
   private static final String GERONIMO_ENVIROMENT = "geronimo";

    public static void main(String[] args) throws Exception{
        int loanId; 
        int status;
        try {
            loanId = Integer.parseInt(args[0]);
            status = Integer.parseInt(args[1]);
        } catch (RuntimeException e) {           
            System.out.println("java -jar LoanStatusChanger.jar <loanId> <status>");
            return;
        }
        
        PropertyLoader propLoader = PropertyLoader.getInstance(CLIENT_PROP_NAME);
        
        Hashtable env = new Hashtable();
        
        String enviroment = propLoader.getValue(ENVIROMENT);
        
        env.put(FACTORY_INITIAL, propLoader.getValue(FACTORY_INITIAL));
		env.put(PROVIDER_URL, propLoader.getValue(PROVIDER_URL));
		
        if(enviroment.equals(JBOSS_ENVIROMENT)){
        	env.put(FACTORY_URL, propLoader.getValue(FACTORY_URL));
        }else if(enviroment.equals(GERONIMO_ENVIROMENT)){
        	env.put(SECURITY_PRINCIPAL, propLoader.getValue(SECURITY_PRINCIPAL));
        	env.put(SECURITY_CREDENTIALS, propLoader.getValue(SECURITY_CREDENTIALS));
        }else {
        	System.out.println("Unsupported Application Server");
        	return;
        }
        
        System.out.println("Changing Loan Status === > ");
        Context context = new InitialContext(env);
        Object objRef = context.lookup(LoanManagerHome.JNDI_NAME);
        LoanManagerHome loanManagerHome = (LoanManagerHome)PortableRemoteObject.narrow(objRef, LoanManagerHome.class);
        LoanManager loanManager = loanManagerHome.create();
        
        loanManager.changeLoanStatus(loanId, status);
        
        System.out.println("Loan Status Changed Successfully !!!");
    }
}
