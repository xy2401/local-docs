package org.apache.geronimo.samples.loan.web;

import java.io.IOException;
import java.util.Collection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.samples.loan.dto.LoanDTO;
import org.apache.geronimo.samples.loan.ejb.LoanManagerLocal;
import org.apache.geronimo.samples.loan.ejb.LoanManagerLocalHome;

public class LoanManagerDispatchServlet extends HttpServlet {

    /**
     * Constructor of the object.
     */
    public LoanManagerDispatchServlet() {
        super();
    }

    /**
     * Destruction of the servlet. <br>
     */
    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
    }

    /**
     * The doGet method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to get.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String page = request.getServletPath();        
        if(page.equals("/register")){
            registerLoan(request, response);
        }else if(page.equals("/listLoans")){
            listLoans(request, response);
        }
    }

    /**
     * The doPost method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to post.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Initialization of the servlet. <br>
     *
     * @throws ServletException if an error occure
     */
    public void init() throws ServletException {       
    }
    
    private void registerLoan(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
        String path = "/jsp/error.jsp";
        String error = null;
        
        String customerName = null;
        double loanAmount = 0;
        double yearlySalary = 0;
        String address = null;
        
        boolean isMissingField = true;
        
        try {
            customerName = req.getParameter("customerName");
            loanAmount = Double.parseDouble(req.getParameter("loanAmount"));
            yearlySalary = Double.parseDouble(req.getParameter("annualSalary"));
            address = req.getParameter("address");
            isMissingField = false;
            
        } catch (RuntimeException e) {
           error = "Missing/Invalid required field : ";
           
           if(customerName == null){
               error += ("Customer Name : "+e.getMessage());
           }else if(address == null){
        	   error += ("Address : "+e.getMessage());
           }else if (loanAmount == 0){
               error += ("Loan Amount : "+e.getMessage());
           }else if(yearlySalary == 0){
               error += ("Annual Salary : "+e.getMessage());
           }
        }
        
        if(!isMissingField){
            try {
                Context context = new InitialContext();
                LoanManagerLocalHome loanHome = (LoanManagerLocalHome)context.lookup(LoanManagerLocalHome.COMP_NAME);
                LoanManagerLocal loanManager = loanHome.create();
                
                LoanDTO dto = new LoanDTO();
                dto.setCustomerName(customerName);
                dto.setLoanAmount(loanAmount);
                dto.setAddress(address);
                dto.setAnnualSalary(yearlySalary);
                
                loanManager.registerLoan(dto);
                path = "/jsp/index.jsp";
            } catch (Exception e) {
                e.printStackTrace();
                error = "Error occured in EJB Layer "+e.getMessage();
            }
        }
        
        if(error != null){
            req.setAttribute("error", error);
        }
        
        getServletContext().getRequestDispatcher(path).forward(req, res);
    }
    
    private void listLoans(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
        String path = "/jsp/error.jsp";
        String error = null;
        
        try {
            Context context = new InitialContext();
            LoanManagerLocalHome loanHome = (LoanManagerLocalHome)context.lookup(LoanManagerLocalHome.COMP_NAME);
            LoanManagerLocal loanManager = loanHome.create();
            
            Collection customerList = loanManager.lisLoans();
            
            req.setAttribute("loansList", customerList);
        
            path = "/jsp/list_loans.jsp";
        } catch (Exception e) {
            e.printStackTrace();
            error = "Error occured in EJB Layer "+e.getMessage();
        }
        
        if(error != null){
        	req.setAttribute("error", error);
        }
        
        getServletContext().getRequestDispatcher(path).forward(req, res);
    }

}
