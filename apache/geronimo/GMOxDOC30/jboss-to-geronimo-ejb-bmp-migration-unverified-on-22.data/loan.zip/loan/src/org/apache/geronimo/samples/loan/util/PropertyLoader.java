package org.apache.geronimo.samples.loan.util;

import java.io.IOException;
import java.util.Properties;

public class PropertyLoader {
    
    private static PropertyLoader instance;
    private Properties properties;

    private PropertyLoader(String fileName) {
        try {
            properties = new Properties();
            properties.load(this.getClass().getClassLoader().getResourceAsStream(fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static PropertyLoader getInstance(String fileName){
        if(instance == null){
            instance = new PropertyLoader(fileName);
        }
        return instance;
    }
    
    public String getValue(String key){
        return (String)properties.get(key);
    }
}
