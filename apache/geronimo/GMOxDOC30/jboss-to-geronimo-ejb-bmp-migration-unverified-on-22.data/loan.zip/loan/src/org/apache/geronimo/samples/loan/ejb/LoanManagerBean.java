package org.apache.geronimo.samples.loan.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.geronimo.samples.loan.dto.LoanDTO;

/**
 *
 * @ejb.bean name="LoanManager"
 *           display-name="LoanManager"
 *           description="LoanManager"
 *           jndi-name="org.apache.geronimo.samples.loan.ejb.LoanManager"
 * 			 local-jndi-name="LoanManager"
 *           type="Stateless"
 *           view-type="both"
 * 
 * @ejb.ejb-ref ejb-name="Loan" view-type="local" ref-name="ejb/LoanLocal"
 * @ejb.interface generate="local,remote" local-class="org.apache.geronimo.samples.loan.ejb.LoanManagerLocal" remote-class="org.apache.geronimo.samples.loan.ejb.LoanManager"
 * @ejb.home generate="local,remote" local-class="org.apache.geronimo.samples.loan.ejb.LoanManagerLocalHome" remote-class=""-class="org.apache.geronimo.samples.loan.ejb.LoanManagerHome"
 */
public class LoanManagerBean implements SessionBean {

    /** The session context */
    private SessionContext context;

    /**
     * 
     */
    public LoanManagerBean() {
        super();
    }

    /**
     * 
     * @throws EJBException Thrown if method fails due to system-level error.
     */
    public void setSessionContext(SessionContext newContext)
        throws EJBException {
        context = newContext;
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove() throws EJBException, RemoteException {
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate() throws EJBException, RemoteException {
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }

    /**
     * @ejb.create-method
     * 
     */
    public void ejbCreate() throws CreateException {
    }

    /**
     * @ejb.interface-method view-type = "local"
     * 
     * @throws EJBException Thrown if method fails due to system-level error.
     */
    public Collection lisLoans() throws EJBException {
        ArrayList list = new ArrayList();
        Context context = null;
        
        try{
            context = new InitialContext();
            LoanHomeLocal loanHome = (LoanHomeLocal)context.lookup(LoanHomeLocal.COMP_NAME);
            Collection loanList = loanHome.findByAll();
            
            for(Iterator iterator = loanList.iterator(); iterator.hasNext();){
                
                LoanLocal loan = (LoanLocal)iterator.next(); 

                LoanDTO loanDTO = new LoanDTO();
                loanDTO.setLoanId(loan.getLoanId().intValue());
                loanDTO.setCustomerName(loan.getCustomerName());
                loanDTO.setLoanAmount(loan.getLoanAmount().doubleValue());
                loanDTO.setAddress(loan.getAddress());
                loanDTO.setAnnualSalary(loan.getAnnualSalary().doubleValue());
                loanDTO.setLoanStatus(loan.getLoanStatus().intValue());
                list.add(loanDTO);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(context != null){
                try {
                    context.close();
                } catch (NamingException e1) {
                    e1.printStackTrace();
                }
            }
        }
        return list;
    }
    
    /**
     * @ejb.interface-method view-type="local"
     * @throws EJBException
     */
    public void registerLoan(LoanDTO dto) throws EJBException {
        Context context = null;
        
        try{
            context = new InitialContext();
            LoanHomeLocal loanHome = (LoanHomeLocal)context.lookup(LoanHomeLocal.COMP_NAME);
            loanHome.create(dto.getCustomerName(), new Double(dto.getLoanAmount()), dto.getAddress(), new Double(dto.getAnnualSalary()));
            
        }catch (Exception e){            
            e.printStackTrace();
        }finally {
            if(context != null){
                try {
                    context.close();
                } catch (NamingException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
    
    /**
     * @ejb.interface-method view-type="both"
     * @return
     * @throws EJBException
     */
    public void changeLoanStatus(int loanId, int status) throws EJBException {

    	Context context = null;
       
       try{
           context = new InitialContext();
           LoanHomeLocal loanHome = (LoanHomeLocal)context.lookup(LoanHomeLocal.COMP_NAME);
           LoanLocal loan = loanHome.findByPrimaryKey(new Integer(loanId));
           loan.setLoanStatus(new Integer(status));// Status Changed
           
       }catch (Exception e){
           e.printStackTrace();
       }finally {
           if(context != null){
               try {
                   context.close();
               } catch (NamingException e1) {
                   e1.printStackTrace();
               }
           }
       }
    }

}