package com.dev.trade.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import com.dev.trade.bo.Stock;
import com.dev.trade.bo.User;
import com.dev.trade.bo.UserStock;
import com.dev.trade.exception.DBException;
import com.dev.trade.util.HibernateUtil;

public class TradeDAO {


	Session session = null;

	public TradeDAO() throws Exception {

	}

	public User getUserByUserId(String userId) throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from User u where u.userId=:userId");
		q.setString("userId", userId);
		return (User) q.uniqueResult();

	}

	public List getUserStocks(String userId) throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from UserStock u where u.userId=:userId");
		q.setString("userId", userId);
		List list =  q.list();
		return list;

	}

	public List getStocks() throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from Stock");
		List stocks = q.list();
		return stocks;

	}

	public float getUserCash(String userId) throws DBException {

		User user = null;
		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from User u where u.userId=:userId");
		q.setString("userId", userId);
		return ((User) q.uniqueResult()).getCash();

	}

	public boolean buyStock(String userId, String stockId, int quantity)
			throws DBException {
		float cashAvailable = getUserCash(userId);
		float costOfStock = getStockPrice(stockId);
		float totalCost = costOfStock * quantity;
		int availableStock = getStockQuantityForUser(userId, stockId);
		cashAvailable = cashAvailable - totalCost;

		if (cashAvailable >= 0 && (availableStock != 0)) {
			availableStock = availableStock + quantity;
			setUserCash(userId, cashAvailable);
			setUserStock(userId, stockId, availableStock);

		} else if (cashAvailable >= 0 && (availableStock == 0)) {
			availableStock = availableStock + quantity;
			setUserCash(userId, cashAvailable);
			addUserStock(userId, stockId, availableStock);

		} else {
			return false;
		}
		return true;
	}

	public boolean sellStock(String userId, String stockId, int quantity)
			throws DBException {
		float cashAvailable = getUserCash(userId);
		float costOfStock = getStockPrice(stockId);
		float totalCost = costOfStock * quantity;
		int availableStock = getStockQuantityForUser(userId, stockId);
		cashAvailable = cashAvailable + totalCost;
		availableStock = availableStock - quantity;
		if (availableStock >= 0) {

			setUserCash(userId, cashAvailable);
			setUserStock(userId, stockId, availableStock);

		} else {
			return false;
		}
		return true;
	}

	public float getStockPrice(String stockId) throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from Stock s where s.id=:id");
		q.setString("id", stockId);
		Stock stock = (Stock) q.uniqueResult();
		return stock.getPrice();

	}

	private boolean setUserCash(String userId, float cash) throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from User u where u.userId=:userId");
		q.setString("userId", userId);
		User user = (User) q.uniqueResult();
		user.setCash(cash);
		session.save(user);
		return true;

	}

	// buy = true sell = false
	private boolean setUserStock(String userId, String stockId, int quantity)
			throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from UserStock u where u.userId=:userId and u.id=:id");
		q.setString("userId", userId);
		q.setString("id", stockId);
		UserStock userStock = (UserStock) q.uniqueResult();
		userStock.setQuantity(quantity);
		if(quantity != 0){
			session.save(userStock);
		}else{
			session.delete(userStock);
		}
		return true;

	}

	private boolean addUserStock(String userId, String stockId, int quantity)
			throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from Stock s where s.id=:id");
		q.setString("id", stockId);
		Stock stock = (Stock) q.uniqueResult();
		UserStock userStock = new UserStock(stock.getId(), stock.getName(), stock.getPrice(),quantity,userId);
		session.save(userStock);
		return true;

	}

	public int getStockQuantityForUser(String userId, String stockId)
			throws DBException {

		session = HibernateUtil.getCurrentSession();
		Query q = session.createQuery("from UserStock u where u.userId=:userId and u.id=:id");
		q.setString("userId", userId);
		q.setString("id", stockId);
		UserStock userStock = (UserStock) q.uniqueResult();
		if(userStock == null){
			return 0;
		}
		return userStock.getQuantity();
	}

	public boolean addUser(String userId, String name, String password,
			String address, float cash) throws DBException {
		session = HibernateUtil.getCurrentSession();
		User user = new User();
		user.setAddress(address);
		user.setCash(cash);
		user.setName(name);
		user.setPassword(password);
		user.setUserId(userId);
		session.save(user);
		return true;
	}

	public void remove() throws DBException {

	}

}
