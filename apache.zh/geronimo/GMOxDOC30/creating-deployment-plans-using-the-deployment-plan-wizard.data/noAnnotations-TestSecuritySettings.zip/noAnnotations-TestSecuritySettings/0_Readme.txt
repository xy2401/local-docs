1) Using "DBManager" portlet, create a database by name "TimeReportDB" and run "1_TimeReportDB.sql" on this new database.

2) Using "Deploy New" portlet, create a new database pool "TimeReportPool" by specifying "<GERONIMO_HOME>\repository\org\tranql\tranql-connector-ra\1.3\tranql-connector-ra-1.3.rar" as the "Archive" and "2_dbPoolPlan.xml" as the "Plan".

3) Using "Deploy New" portlet, create a new security realm "TimeReportRealm" by only specifying "3_securityRealmPlan.xml" as the "Plan".

4) Finally create the geronimo-web.xml for "timereport.war" by using "Create Plan" portlet as below: 
a) In the 'security configuration' page, select "TimeReportRealm" as the "Security Realm Name".
b) For security role "employee", select "Add -> Principal" and add 2 "Group Prinicipals" with name "EmployeeGroup" and "ManagerGroup".
c) For security role "manager", select "Add -> Principal" and add 1 "Group Prinicipal" with name "ManagerGroup".
d) Press "Next" twice.
e) In the 'created plan' page, you should see a plan similar to "timereport_generatedPlan.xml".
f) Press "Deploy WAR" and click on "Launch Web App" to run the sample application.
g) Verify using "userid" and "password" values from "1_TimeReportDB.sql".