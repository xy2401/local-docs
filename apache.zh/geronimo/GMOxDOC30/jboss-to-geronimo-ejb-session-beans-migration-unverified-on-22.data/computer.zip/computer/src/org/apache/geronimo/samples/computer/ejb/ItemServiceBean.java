/*
 * Created on Nov 12, 2006
 *
 * 
 */
package org.apache.geronimo.samples.computer.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import javax.ejb.CreateException;

import org.apache.geronimo.samples.computer.dto.ItemDTO;

/**
 *  
 * @ejb.bean name="ItemService"
 *           display-name="ItemService"
 *           description="ItemService"
 *           local-jndi-name="ItemService"
 *           type="Stateless"
 *           view-type="local"
 * @ejb.interface generate="local" local-class="org.apache.geronimo.samples.computer.ejb.ItemServiceLocal"
 * @ejb.home  generate="local" local-class="org.apache.geronimo.samples.computer.ejb.ItemServiceLocalHome"
 */
public class ItemServiceBean implements SessionBean {

	private static final long serialVersionUID = -3420188256774564384L;
	/** The session context */
    private SessionContext context;

    /**
     * 
     */
    public ItemServiceBean() {
        super();
    }

    /**
     * Set the associated session context. The container calls this method 
     * after the instance creation.
     * 
     * The enterprise bean instance should store the reference to the context 
     * object in an instance variable.
     * 
     * This method is called with no transaction context. 
     * 
     * @throws EJBException Thrown if method fails due to system-level error.
     */
    public void setSessionContext(SessionContext newContext)
        throws EJBException {
        context = newContext;
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove() throws EJBException, RemoteException {
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate() throws EJBException, RemoteException {
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }

    /**
     * An ejbCreate method as required by the EJB specification.
     * 
     * The container calls the instance?s <code>ejbCreate</code> method whose
     * signature matches the signature of the <code>create</code> method invoked
     * by the client. The input parameters sent from the client are passed to
     * the <code>ejbCreate</code> method. Each session bean class must have at
     * least one <code>ejbCreate</code> method. The number and signatures
     * of a session bean?s <code>create</code> methods are specific to each 
     * session bean class.
     * 
     * @throws CreateException Thrown if method fails due to system-level error.
     * 
     * @ejb.create-method
     * 
     */
    public void ejbCreate() throws CreateException {
    }

    /**
     * 
     * @ejb.interface-method view-type = "local"
     * 
     * @throws EJBException Thrown if method fails due to system-level error.
     */
    public List listItems() {
        List items = new ArrayList();
        
        //Add Processory Informatios
        ItemDTO processor = new ItemDTO();
        processor.setItemId(1);
        processor.setDescription("PENTIUM-4 2.8 GZ Processor");
        processor.setUnitPrice(12000);
        processor.setDiscountPercentage(.05);
        processor.setMinimumDiscountPurchase(10);
        
        //Add Hard Disk Information
        ItemDTO hardDisk = new ItemDTO();
        hardDisk.setItemId(2);
        hardDisk.setDescription("120 GB Hard disk");
        hardDisk.setUnitPrice(9500);
        hardDisk.setDiscountPercentage(.05);
        hardDisk.setMinimumDiscountPurchase(8);
        
        //Add CPU Fan Information
        ItemDTO processorFan = new ItemDTO();
        processorFan.setItemId(3);
        processorFan.setDescription("10W CPU Fan");
        processorFan.setUnitPrice(3500);
        processorFan.setDiscountPercentage(.02);
        processorFan.setMinimumDiscountPurchase(15);
        
        //Add RAM Module Information
        ItemDTO ram = new ItemDTO();
        ram.setItemId(4);
        ram.setDescription("1G DDR RAM");
        ram.setUnitPrice(11500);
        ram.setDiscountPercentage(.08);
        ram.setMinimumDiscountPurchase(10);
        
        //Add VGA Card Information
        ItemDTO vga = new ItemDTO();
        vga.setItemId(5);
        vga.setDescription("256MB VGA Card");
        vga.setUnitPrice(5000);
        vga.setDiscountPercentage(.05);
        vga.setMinimumDiscountPurchase(5);
        
        //Add Sound Card Information
        ItemDTO soundCard = new ItemDTO();
        soundCard.setItemId(6);
        soundCard.setDescription("128bit Sound Card");
        soundCard.setUnitPrice(4000);
        soundCard.setDiscountPercentage(.1);
        soundCard.setMinimumDiscountPurchase(10);
        
        //Add Monitor Information
        ItemDTO monitor = new ItemDTO();
        monitor.setItemId(7);
        monitor.setDescription("17' LCD Monitor");
        monitor.setUnitPrice(22000);
        monitor.setDiscountPercentage(.1);
        monitor.setMinimumDiscountPurchase(5);
        
        //Add TV Card Information
        ItemDTO tvCard = new ItemDTO();
        tvCard.setItemId(8);
        tvCard.setDescription("TV Card");
        tvCard.setUnitPrice(5000);
        tvCard.setDiscountPercentage(.1);
        tvCard.setMinimumDiscountPurchase(2);
        
        //Add Radio Card Information
        ItemDTO radioCard = new ItemDTO();
        radioCard.setItemId(9);
        radioCard.setDescription("Radio Card");
        radioCard.setUnitPrice(3000);
        radioCard.setDiscountPercentage(.15);
        radioCard.setMinimumDiscountPurchase(2);
        
        //Add Printer Information
        ItemDTO printer = new ItemDTO();
        printer.setItemId(10);
        printer.setDescription("Bubble-jet Printer");
        printer.setUnitPrice(4500);
        printer.setDiscountPercentage(.15);
        printer.setMinimumDiscountPurchase(5);
        
        items.add(processor);
        items.add(hardDisk);
        items.add(processorFan);
        items.add(ram);
        items.add(vga);
        items.add(soundCard);       
        items.add(monitor);       
        items.add(tvCard);       
        items.add(radioCard);       
        items.add(printer);       
        
        return items;
    }
    
    /**
     * @ejb.interface-method view-type = "local"
     * @param item
     * @param quantity
     * @return
     */
    public double calculatePrice(ItemDTO item, int quantity){
        double price = 0.0;
        
        if(quantity >= item.getMinimumDiscountPurchase()){
            price = ((1.0 - item.getDiscountPercentage())*item.getUnitPrice()) * quantity;
        }else {
            price = item.getUnitPrice() * quantity;
        }
        
        return price;
    }

}