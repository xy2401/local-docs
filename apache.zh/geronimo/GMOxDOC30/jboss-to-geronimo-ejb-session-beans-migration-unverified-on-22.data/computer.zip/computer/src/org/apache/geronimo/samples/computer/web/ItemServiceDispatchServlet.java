/*
 * Created on Nov 12, 2006
 *
 * 
 */
package org.apache.geronimo.samples.computer.web;

import java.io.IOException;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.samples.computer.ejb.ItemServiceLocal;
import org.apache.geronimo.samples.computer.ejb.ItemServiceLocalHome;

public class ItemServiceDispatchServlet extends HttpServlet {

	private static final long serialVersionUID = -3351294634090089534L;

	/**
     * Constructor of the object.
     */
    public ItemServiceDispatchServlet() {
        super();
    }

    /**
     * Destruction of the servlet. <br>
     */
    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }

    /**
     * The doGet method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to get.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String page = request.getServletPath();
        
        if(page.equals("/listItems")){
            listItems(request, response);
        }else if(page.equals("/buyItem")){
            buyItem(request, response);
        }
        
    }

    /**
     * The doPost method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to post.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Initialization of the servlet. <br>
     *
     * @throws ServletException if an error occure
     */
    public void init() throws ServletException {
        // Put your code here
    }
    
    private void listItems(HttpServletRequest request, HttpServletResponse response) 
    		throws ServletException, IOException {
        String path = "/jsp/error.jsp";
        String error = null;
        
        try {
            Context context = new InitialContext();
            ItemServiceLocalHome home = (ItemServiceLocalHome)context.lookup(ItemServiceLocalHome.COMP_NAME);
            ItemServiceLocal itemService = home.create();
            List itemList = itemService.listItems();
            
            request.getSession().setAttribute("itemList",itemList);
            path = "/jsp/list_items.jsp";
            
        } catch (NamingException e) {
            error = "ItemService EJB not found";
        } catch (CreateException e) {
            error = "ItemService Instance can not be created";
        } catch (Exception e){
        	e.printStackTrace();
            error = "Undefined State Exception";
        }
        
        if(error != null){
            request.setAttribute("error", error);
        }
            
        getServletContext().getRequestDispatcher(path).forward(request, response);
    }
    
    private void buyItem(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/jsp/error.jsp";
		String error = null;
		String itemId = request.getParameter("itemId");
		
		if(itemId != null && !itemId.equals("")){
		    request.setAttribute("itemId",itemId);
			path = "/jsp/buy_item.jsp";
		}else {
		    error = "Undefined State Exception";
		}
		
		if(error != null){
		    request.setAttribute("error",error);
		}

		getServletContext().getRequestDispatcher(path).forward(request, response);        
    }
  
}
