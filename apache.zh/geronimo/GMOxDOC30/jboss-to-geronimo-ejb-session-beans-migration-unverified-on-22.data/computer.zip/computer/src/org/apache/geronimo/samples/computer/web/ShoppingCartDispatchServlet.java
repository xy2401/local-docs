/*
 * Created on Nov 13, 2006
 *
 * 
 */
package org.apache.geronimo.samples.computer.web;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.samples.computer.dto.ItemDTO;
import org.apache.geronimo.samples.computer.ejb.ShoppingCartLocal;
import org.apache.geronimo.samples.computer.ejb.ShoppingCartLocalHome;

public class ShoppingCartDispatchServlet extends HttpServlet {

	private static final long serialVersionUID = 3595079963765646121L;

	/**
     * Constructor of the object.
     */
    public ShoppingCartDispatchServlet() {
        super();
    }

    /**
     * Destruction of the servlet. <br>
     */
    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }

    /**
     * The doGet method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to get.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String page = request.getServletPath();
        
        if(page.equals("/addToCart")){
            addToCart(request, response);
        }else if(page.equals("/removeTransaction")){
            removeTransaction(request, response);
        }
    }

    /**
     * The doPost method of the servlet. <br>
     *
     * This method is called when a form has its tag value method equals to post.
     * 
     * @param request the request send by the client to the server
     * @param response the response send by the server to the client
     * @throws ServletException if an error occurred
     * @throws IOException if an error occurred
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request , response);
    }

    /**
     * Initialization of the servlet. <br>
     *
     * @throws ServletException if an error occure
     */
    public void init() throws ServletException {
        // Put your code here
    }
    
    private void addToCart(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        
        String path = "/jsp/error.jsp";
        String error = null;
        
        boolean isValidQuantity = false; 
        try {
            int quantity = Integer.parseInt((String)request.getParameter("quantity"));
            isValidQuantity = true;
            
            String itemId = (String)request.getParameter("itemId");
            Object obj = request.getSession().getAttribute("shoppingCart");
            
            ShoppingCartLocal cart = null;
            if(obj == null){
                Context context = new InitialContext();
                ShoppingCartLocalHome home = (ShoppingCartLocalHome)context.lookup(ShoppingCartLocalHome.COMP_NAME);
                cart = home.create();
                request.getSession().setAttribute("shoppingCart",cart);
            }else {
                cart = (ShoppingCartLocal)obj;
            }
            
            List itemList = (List)request.getSession().getAttribute("itemList");
            
            for(Iterator iterator = itemList.iterator(); iterator.hasNext();){
                ItemDTO item = (ItemDTO)iterator.next();
                
                if(item.getItemId() == Integer.parseInt(itemId)){
                    boolean status = cart.addToCart(item, quantity);
                    
                    if(status){//successfully added to the cart
                        double total = cart.getTotal();
                        List transactionList = cart.listCartTransactions();
                        request.setAttribute("transactionList", transactionList);
                        request.setAttribute("total", new Double(total));
                        
                        path = "/jsp/shopping_cart.jsp";
                    }else {
                        error = "Can't Add same Item to the Shopping Cart Twise";
                    }
                    break;
                }
            }
            
        } catch (NamingException e) {
            error = "ShoppingCart EJB not found";
        } catch (CreateException e) {
            error = "ShoppingCart Instance can not be created";
        } catch (Exception e){
        	if(isValidQuantity){
        		error = "Undefined State Exception";
        	}else {
        		error = "Invalid Number format to Quantity Field";
        	}
            
        }
        
        if(error != null){
            request.setAttribute("error", error);
        }
            
        getServletContext().getRequestDispatcher(path).forward(request, response);
    }
    
    private void removeTransaction(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
        
        String path = "/jsp/error.jsp";
        String error = null;
        
        try {
            String itemId = (String)request.getParameter("itemId");            
            Object obj = request.getSession().getAttribute("shoppingCart");
            
            if(obj != null){
                ShoppingCartLocal cart = (ShoppingCartLocal)obj;
                cart.removeTransaction(Integer.parseInt(itemId));
                path = "/listItems";
            }else {
                error = "Undefined State Exception";
            }
        } catch (NumberFormatException e) {        
           error = "Undefined State Exception";
        }
        
        if(error != null){
           request.setAttribute("error",error); 
        }
        
        getServletContext().getRequestDispatcher(path).forward(request, response);
    }

}
