/*
 * Created on Nov 13, 2006
 *
 * 
 */
package org.apache.geronimo.samples.computer.ejb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.geronimo.samples.computer.dto.ItemDTO;
import org.apache.geronimo.samples.computer.dto.TransactionDTO;

/**
 * 
 * @ejb.bean name="ShoppingCart"
 *           display-name="ShoppingCart"
 *           description="ShoppingCart"
 *           local-jndi-name="ShoppingCart"
 *           type="Stateful"
 *           view-type="local"
 * @ejb.ejb-ref ejb-name="ItemService" view-type="local" ref-name="ejb/ItemServiceLocal"
 * 
 * @ejb.interface generate="local" local-class="org.apache.geronimo.samples.computer.ejb.ShoppingCartLocal"
 * @ejb.home  generate="local" local-class="org.apache.geronimo.samples.computer.ejb.ShoppingCartLocalHome"
 */
public class ShoppingCartBean implements SessionBean {

	private static final long serialVersionUID = -5052586584698389813L;
	/** The session context */
    private SessionContext context;
    private List transactionList;

    /**
     * 
     */
    public ShoppingCartBean() {
        super();
    }

    /**
     * Set the associated session context. The container calls this method 
     * after the instance creation.
     * 
     * The enterprise bean instance should store the reference to the context 
     * object in an instance variable.
     * 
     * This method is called with no transaction context. 
     * 
     * @throws EJBException Thrown if method fails due to system-level error.
     */
    public void setSessionContext(SessionContext newContext)
        throws EJBException {
        context = newContext;
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbRemove()
     */
    public void ejbRemove() throws EJBException, RemoteException {

    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbActivate()
     */
    public void ejbActivate() throws EJBException, RemoteException {
    }

    /* (non-Javadoc)
     * @see javax.ejb.SessionBean#ejbPassivate()
     */
    public void ejbPassivate() throws EJBException, RemoteException {
    }

    /**
     * Default create method
     * 
     * @throws CreateException
     * @ejb.create-method
     */
    public void ejbCreate() throws CreateException {
        transactionList = new ArrayList();
    }

    /**
     * @ejb.interface-method view-type = "local"
     */
    public boolean addToCart(ItemDTO item, int quantity) throws EJBException {
        boolean status = false;
        
        try {
            for(Iterator iterator = transactionList.iterator(); iterator.hasNext();){
                TransactionDTO temTransaction = (TransactionDTO)iterator.next();                
                if(temTransaction.getItemId() == item.getItemId()){
                    return status;
                }
            }
            
            TransactionDTO transaction = new TransactionDTO();
            
            transaction.setItemId(item.getItemId());
            transaction.setQuantity(quantity);
            
            
            Context context = new InitialContext();
            ItemServiceLocalHome itemHome = (ItemServiceLocalHome)context.lookup(ItemServiceLocalHome.COMP_NAME);
            ItemServiceLocal itemService = itemHome.create();
            
            double newPrice = itemService.calculatePrice(item, quantity);
            double originalPrice = item.getUnitPrice() * quantity;
            
            if(originalPrice != newPrice){
                transaction.setDiscountRecieved(originalPrice - newPrice);
            }

            transaction.setPrice(newPrice);
            transactionList.add(transaction);
            
            status = true;
            
        } catch (NamingException e) {
        } catch (CreateException e) {
        }
        
        return status;
    }
    
    /**
    *
    * @ejb.interface-method view-type = "local"
    * 
    */
   public List listCartTransactions(){
       return transactionList;
   }
   
   /**
    * @ejb.interface-method view-type = "local"
    */
   public double getTotal() {
       double total = 0.0;
       for(Iterator iterator= transactionList.iterator(); iterator.hasNext();){
           TransactionDTO transaction = (TransactionDTO)iterator.next();
           
           total += transaction.getPrice();
       }
       return total;
   }
   
   /**
    * @ejb.interface-method view-type = "local"
    */
   public void removeTransaction(int itemId) {
       for(Iterator iterator= transactionList.iterator(); iterator.hasNext();){
           TransactionDTO transaction = (TransactionDTO)iterator.next();
           
           if(transaction.getItemId() == itemId){
               transactionList.remove(transaction);
               break;
           }
           
       }
   }
  

}