/*
 * Created on Nov 12, 2006
 *
 * 
 */
package org.apache.geronimo.samples.computer.dto;

import java.io.Serializable;

public class ItemDTO implements Serializable{
    
	private static final long serialVersionUID = 1630580339616364472L;
	
	private double unitPrice;
    private String description;
    private int minimumDiscountPurchase;
    private double discountPercentage;
    private int itemId;

    /**
     * @return Returns the description.
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return Returns the discountPercentage.
     */
    public double getDiscountPercentage() {
        return discountPercentage;
    }
    /**
     * @param discountPercentage The discountPercentage to set.
     */
    public void setDiscountPercentage(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }
    /**
     * @return Returns the minimumDiscountPurchase.
     */
    public int getMinimumDiscountPurchase() {
        return minimumDiscountPurchase;
    }
    /**
     * @param minimumDiscountPurchase The minimumDiscountPurchase to set.
     */
    public void setMinimumDiscountPurchase(int minimumDiscountPurchase) {
        this.minimumDiscountPurchase = minimumDiscountPurchase;
    }
    /**
     * @return Returns the unitPrice.
     */
    public double getUnitPrice() {
        return unitPrice;
    }
    /**
     * @param unitPrice The unitPrice to set.
     */
    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }
    
    /**
     * @return Returns the itemId.
     */
    public int getItemId() {
        return itemId;
    }
    /**
     * @param itemId The itemId to set.
     */
    public void setItemId(int itemId) {
        this.itemId = itemId;
    }
}
