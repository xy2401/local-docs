/*
 * Created on Nov 13, 2006
 *
 * 
 */
package org.apache.geronimo.samples.computer.dto;

import java.io.Serializable;

public class TransactionDTO implements Serializable{
    
	private static final long serialVersionUID = 5607246400461657743L;
	private int itemId;
    private int quantity;
    private double discountRecieved;
    private double price;

    /**
     * 
     */
    public TransactionDTO() {
        super();
    }
    
    /**
     * @return Returns the discountRecieved.
     */
    public double getDiscountRecieved() {
        return discountRecieved;
    }
    /**
     * @param discountRecieved The discountRecieved to set.
     */
    public void setDiscountRecieved(double discountRecieved) {
        this.discountRecieved = discountRecieved;
    }
    /**
     * @return Returns the itemId.
     */
    public int getItemId() {
        return itemId;
    }
    /**
     * @param itemId The itemId to set.
     */
    public void setItemId(int itemId) {
        this.itemId = itemId;
    }
    /**
     * @return Returns the price.
     */
    public double getPrice() {
        return price;
    }
    /**
     * @param price The price to set.
     */
    public void setPrice(double price) {
        this.price = price;
    }
    /**
     * @return Returns the quantity.
     */
    public int getQuantity() {
        return quantity;
    }
    /**
     * @param quantity The quantity to set.
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
